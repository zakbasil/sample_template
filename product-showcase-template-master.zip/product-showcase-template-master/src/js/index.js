require("bootstrap");
require("@fortawesome/fontawesome-free/js/all.js");
window.$ = window.jQuery = require("jquery");
require("../vendor/smooth-scroll/navbar-fixed");
